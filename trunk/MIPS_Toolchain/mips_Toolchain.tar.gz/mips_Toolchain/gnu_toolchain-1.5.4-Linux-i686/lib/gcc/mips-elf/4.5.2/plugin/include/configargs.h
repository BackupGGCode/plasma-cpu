/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-4.5.2/configure --target=mips-elf --prefix=/home/theshadowx7/Bureau/mips/gnu_toolchain-1.5.4-Linux-i686 --disable-nls --disable-threads --disable-shared --enable-static --with-gcc --with-gnu-ld --with-gnu-as --with-dwarf2 --enable-languages=c,c++ --with-newlib --with-sysroot=../newlib-1.19.0/newlib/libc/include --disable-libssp --disable-libstdcxx-pch --disable-libmudflap --disable-libgomp -v --with-libelf=/home/theshadowx7/Bureau/mips/addontools-1.5.4-Linux-i686 --with-gmp=/home/theshadowx7/Bureau/mips/addontools-1.5.4-Linux-i686 --with-mpfr=/home/theshadowx7/Bureau/mips/addontools-1.5.4-Linux-i686 --with-mpc=/home/theshadowx7/Bureau/mips/addontools-1.5.4-Linux-i686";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "synci", "no-synci" } };
